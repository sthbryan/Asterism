# @zovaris/sephiro

Composable UI primitives for desktop apps. Small, themeable React components with semantic tokens. No global reset. Works with React and Preact.

## Install

```bash
bun add @zovaris/sephiro
```

```tsx
import { Button, Field, Input, Select, Toggle } from "@zovaris/sephiro";
import "@zovaris/sephiro/styles.css";
```

`styles.css` is the complete, backwards-compatible bundle. It contains the
Sephiro theme tokens and every component rule, but no reset, global Tailwind
layer, or universal selector.

Tailwind 4 consumers can also keep the two concerns explicit:

```tsx
import "@zovaris/sephiro/themes.css";
import "@zovaris/sephiro/components.css";
```

Import only `components.css` when the host defines the `--sph-*` token contract
itself. The published CSS is already compiled; consumers do not need to add
Sephiro to Tailwind's source scan.

## Themed usage

```tsx
<main data-sephiro-theme="asterism">
  <Button variant="primary">Open workspace</Button>
</main>
```

Available presets: `default`, `dark`, `light`, `asterism`, `fizza`, and `pulso`. The default, dark, and light presets use the pine-rose palette; Pulso remains light by default with a forest-green accent and follows `data-theme="dark"` from its own element or an ancestor. Multiple themes can coexist on one page through `data-sephiro-theme` on any ancestor.

## Sizing

One control size contract: `sm` (32px), `md` (36px, default), `lg` (40px).

## Docs

Full documentation, component catalog, and theming guide: [zovaris/sephiro](https://github.com/Zovaris/sephiro-toolkit).

The current package source and future releases use the [PolyForm Perimeter License 1.0.0](./LICENSE), a source-available license that restricts using Sephiro to provide a competing product. See [NOTICE](./NOTICE) for the required copyright notice. Previously published npm versions remain under the license included with each release.

## Compact data visualizations

`TimeSeriesChart` positions points by their timestamps instead of evenly spaced
categories. It shows the active value and date, supports pointer inspection and
Arrow/Home/End keyboard navigation, and handles single samples, irregular dates,
negative values, and invalid input. Timestamps are application-defined; supply
`formatDate` to choose units, locale, and timezone. `onActivePointChange` can
connect selection to another view.

```tsx
import {
  TimeSeriesChart,
  ColumnChart,
  BarList,
  PopNumber,
} from "@zovaris/sephiro";

<TimeSeriesChart
  label="Repository stars"
  points={[
    { ts: 1700000000, value: 12 },
    { ts: 1700200000, value: 24 },
  ]}
  formatDate={(ts) => new Date(ts * 1000).toLocaleDateString()}
  formatValue={(value) => value.toLocaleString()}
/>;
```

`ColumnChart` displays compact daily columns with a keyboard-focusable button
for every sample. It accepts `{ ts, value, hint? }`, an accessible `label`,
`formatDate`, `formatValue`, and optional `formatDetail` for contextual counts.
`BarList` displays horizontal ranked rows from `{ label, value, color? }`; its
`displayLabel` may shorten visible names while keeping full accessible names,
and `onSelect(item, index)` turns rows into actions. Both support empty text
and consume the active Sephiro palette.

`PopNumber` accepts an already formatted string (`value="1.2k"`) and animates
its characters when it changes. Unlike `AnimatedNumber`, it does not count
through intermediate numeric values. Both reduced-motion settings stop the
animation.
